package template;

public class CompraVirtual extends ProcessamentoDePedido {

	public CompraVirtual(Pedido pedido) {
		super(pedido);
	}
	
	public void selecionarProdutos( boolean embalar) {
		System.out.println("Produtos existem no estoque e adicionados no carrinho");
		embalarParaPresente(embalar);
	}
	public void efetuarPagamento() {
		System.out.println("Pagamento feito com PayPal online");
	}
	public void entregarPedido() {
		System.out.println("Parabens! Seu pedido esta na transportadora e chegará amanhã");

	}
	
	

}
