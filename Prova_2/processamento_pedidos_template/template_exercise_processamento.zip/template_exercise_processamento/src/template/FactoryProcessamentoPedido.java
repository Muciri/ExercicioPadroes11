package template;

public class FactoryProcessamentoPedido {

	public static ProcessamentoDePedido create(String tipoDeCompra) {
		if( tipoDeCompra.equalsIgnoreCase("virtual"))
			return new CompraVirtual(new Pedido());
		else if ( tipoDeCompra.equalsIgnoreCase("fisico"))
			return new CompraFisica(new Pedido());
		else
			return null;
		
		
	}
}
