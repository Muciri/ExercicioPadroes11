package template;

public abstract class ProcessamentoDePedido {
	private Pedido pedido;
	
	public ProcessamentoDePedido(Pedido pedido) {
		this.pedido = pedido;
	}
	
	public void processar(boolean embalar) {
		selecionarProdutos(embalar);
		efetuarPagamento();
		entregarPedido();
	}
	public void embalarParaPresente(boolean embalar) {
		System.out.println(embalar?"Pedido embalado para presente":"");		
	}
	abstract void selecionarProdutos(boolean embalar);
	abstract void efetuarPagamento();
	abstract void entregarPedido();
}
