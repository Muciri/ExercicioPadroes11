package template;

import java.util.Scanner;

public class MainPedidos {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.println("Digite \"virtual\" para compra online ou \"fisico\" para compra na loja");
		String escolha = input.nextLine( );
		
		ProcessamentoDePedido compra = FactoryProcessamentoPedido.create(escolha);
		compra.processar(true);
		
		
		
		
		
		
		
		compra.processar(false);

	}

}
