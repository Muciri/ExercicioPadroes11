package template;

public class CompraFisica extends ProcessamentoDePedido {
	public CompraFisica(Pedido pedido) {
		super(pedido);
	}
	
	public void selecionarProdutos( boolean embalar) {
		System.out.println("Produtos retirados da prateleira");
		embalarParaPresente(embalar);
	}
	public void efetuarPagamento() {
		System.out.println("Pagamento feito em dinheiro no CAIXA");
	}
	public void entregarPedido() {
		System.out.println("Produtos colocados na sacola");

	}

}
